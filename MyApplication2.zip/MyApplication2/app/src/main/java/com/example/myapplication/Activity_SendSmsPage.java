package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity_SendSmsPage extends AppCompatActivity {
    Button btnSend;
    Button btnClearSMS;
    EditText txtPhoneNumber;
    EditText txtMessage;
    String phoneNo;
    String message;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_s_m_s_page);

        txtPhoneNumber = findViewById(R.id.txtPhoneNumber);
        txtMessage = findViewById(R.id.txtSendSMS);
        btnSend = findViewById(R.id.btnSend);
        btnClearSMS = findViewById(R.id.btnClearSMS);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                phoneNo = txtPhoneNumber.getText().toString();
                message = txtMessage.getText().toString();
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms",phoneNo, null));
                intent.putExtra("sms_body", message);
                startActivity(intent);

                Toast.makeText(Activity_SendSmsPage.this, "SMS Sent", Toast.LENGTH_SHORT).show();
            }
        });

        btnClearSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtPhoneNumber.setText("");
                txtMessage.setText("");

            }
        });

    }
}